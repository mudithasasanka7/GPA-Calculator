﻿namespace GPA_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.code1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.examResult1 = new System.Windows.Forms.TextBox();
            this.code2 = new System.Windows.Forms.TextBox();
            this.examResult2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.code3 = new System.Windows.Forms.TextBox();
            this.examResult3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.code4 = new System.Windows.Forms.TextBox();
            this.examResult4 = new System.Windows.Forms.TextBox();
            this.code5 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.code6 = new System.Windows.Forms.TextBox();
            this.examResult5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.examResult6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.code7 = new System.Windows.Forms.TextBox();
            this.examResult7 = new System.Windows.Forms.TextBox();
            this.code8 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.code9 = new System.Windows.Forms.TextBox();
            this.examResult8 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.examResult9 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.outputResult = new System.Windows.Forms.Label();
            this.calculate = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // code1
            // 
            this.code1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code1.Location = new System.Drawing.Point(152, 55);
            this.code1.Name = "code1";
            this.code1.Size = new System.Drawing.Size(66, 38);
            this.code1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Subject :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(135, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Code";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(253, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "Result";
            // 
            // examResult1
            // 
            this.examResult1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult1.Location = new System.Drawing.Point(268, 55);
            this.examResult1.Name = "examResult1";
            this.examResult1.Size = new System.Drawing.Size(66, 38);
            this.examResult1.TabIndex = 0;
            // 
            // code2
            // 
            this.code2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code2.Location = new System.Drawing.Point(152, 100);
            this.code2.Name = "code2";
            this.code2.Size = new System.Drawing.Size(66, 38);
            this.code2.TabIndex = 0;
            // 
            // examResult2
            // 
            this.examResult2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult2.Location = new System.Drawing.Point(268, 100);
            this.examResult2.Name = "examResult2";
            this.examResult2.Size = new System.Drawing.Size(66, 38);
            this.examResult2.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 32);
            this.label4.TabIndex = 1;
            this.label4.Text = "Subject :";
            // 
            // code3
            // 
            this.code3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code3.Location = new System.Drawing.Point(152, 146);
            this.code3.Name = "code3";
            this.code3.Size = new System.Drawing.Size(66, 38);
            this.code3.TabIndex = 0;
            // 
            // examResult3
            // 
            this.examResult3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult3.Location = new System.Drawing.Point(268, 146);
            this.examResult3.Name = "examResult3";
            this.examResult3.Size = new System.Drawing.Size(66, 38);
            this.examResult3.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 32);
            this.label5.TabIndex = 1;
            this.label5.Text = "Subject :";
            // 
            // code4
            // 
            this.code4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code4.Location = new System.Drawing.Point(152, 191);
            this.code4.Name = "code4";
            this.code4.Size = new System.Drawing.Size(66, 38);
            this.code4.TabIndex = 0;
            // 
            // examResult4
            // 
            this.examResult4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult4.Location = new System.Drawing.Point(268, 191);
            this.examResult4.Name = "examResult4";
            this.examResult4.Size = new System.Drawing.Size(66, 38);
            this.examResult4.TabIndex = 0;
            // 
            // code5
            // 
            this.code5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code5.Location = new System.Drawing.Point(152, 236);
            this.code5.Name = "code5";
            this.code5.Size = new System.Drawing.Size(66, 38);
            this.code5.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 32);
            this.label6.TabIndex = 1;
            this.label6.Text = "Subject :";
            // 
            // code6
            // 
            this.code6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code6.Location = new System.Drawing.Point(152, 282);
            this.code6.Name = "code6";
            this.code6.Size = new System.Drawing.Size(66, 38);
            this.code6.TabIndex = 0;
            // 
            // examResult5
            // 
            this.examResult5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult5.Location = new System.Drawing.Point(268, 236);
            this.examResult5.Name = "examResult5";
            this.examResult5.Size = new System.Drawing.Size(66, 38);
            this.examResult5.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 32);
            this.label7.TabIndex = 1;
            this.label7.Text = "Subject :";
            // 
            // examResult6
            // 
            this.examResult6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult6.Location = new System.Drawing.Point(268, 282);
            this.examResult6.Name = "examResult6";
            this.examResult6.Size = new System.Drawing.Size(66, 38);
            this.examResult6.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 285);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 32);
            this.label8.TabIndex = 1;
            this.label8.Text = "Subject :";
            // 
            // code7
            // 
            this.code7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code7.Location = new System.Drawing.Point(152, 327);
            this.code7.Name = "code7";
            this.code7.Size = new System.Drawing.Size(66, 38);
            this.code7.TabIndex = 0;
            // 
            // examResult7
            // 
            this.examResult7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult7.Location = new System.Drawing.Point(268, 327);
            this.examResult7.Name = "examResult7";
            this.examResult7.Size = new System.Drawing.Size(66, 38);
            this.examResult7.TabIndex = 0;
            // 
            // code8
            // 
            this.code8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code8.Location = new System.Drawing.Point(152, 372);
            this.code8.Name = "code8";
            this.code8.Size = new System.Drawing.Size(66, 38);
            this.code8.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 330);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(134, 32);
            this.label9.TabIndex = 1;
            this.label9.Text = "Subject :";
            // 
            // code9
            // 
            this.code9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.code9.Location = new System.Drawing.Point(152, 418);
            this.code9.Name = "code9";
            this.code9.Size = new System.Drawing.Size(66, 38);
            this.code9.TabIndex = 0;
            // 
            // examResult8
            // 
            this.examResult8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult8.Location = new System.Drawing.Point(268, 372);
            this.examResult8.Name = "examResult8";
            this.examResult8.Size = new System.Drawing.Size(66, 38);
            this.examResult8.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 375);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(134, 32);
            this.label10.TabIndex = 1;
            this.label10.Text = "Subject :";
            // 
            // examResult9
            // 
            this.examResult9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examResult9.Location = new System.Drawing.Point(268, 418);
            this.examResult9.Name = "examResult9";
            this.examResult9.Size = new System.Drawing.Size(66, 38);
            this.examResult9.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 421);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 32);
            this.label11.TabIndex = 1;
            this.label11.Text = "Subject :";
            // 
            // outputResult
            // 
            this.outputResult.AutoSize = true;
            this.outputResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputResult.Location = new System.Drawing.Point(473, 236);
            this.outputResult.Name = "outputResult";
            this.outputResult.Size = new System.Drawing.Size(101, 32);
            this.outputResult.TabIndex = 1;
            this.outputResult.Text = "Result";
            // 
            // calculate
            // 
            this.calculate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.calculate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculate.Location = new System.Drawing.Point(444, 309);
            this.calculate.Name = "calculate";
            this.calculate.Size = new System.Drawing.Size(181, 72);
            this.calculate.TabIndex = 2;
            this.calculate.Text = "Calculate";
            this.calculate.UseVisualStyleBackColor = true;
            this.calculate.Click += new System.EventHandler(this.calculate_Click);
            // 
            // clear
            // 
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(458, 395);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(147, 58);
            this.clear.TabIndex = 3;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 501);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.calculate);
            this.Controls.Add(this.outputResult);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.examResult9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.examResult6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.examResult8);
            this.Controls.Add(this.examResult3);
            this.Controls.Add(this.examResult5);
            this.Controls.Add(this.code9);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.code6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.examResult2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.code8);
            this.Controls.Add(this.code3);
            this.Controls.Add(this.code5);
            this.Controls.Add(this.examResult7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.examResult4);
            this.Controls.Add(this.code7);
            this.Controls.Add(this.code2);
            this.Controls.Add(this.code4);
            this.Controls.Add(this.examResult1);
            this.Controls.Add(this.code1);
            this.Name = "Form1";
            this.Text = "GPA Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox code1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox examResult1;
        private System.Windows.Forms.TextBox code2;
        private System.Windows.Forms.TextBox examResult2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox code3;
        private System.Windows.Forms.TextBox examResult3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox code4;
        private System.Windows.Forms.TextBox examResult4;
        private System.Windows.Forms.TextBox code5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox code6;
        private System.Windows.Forms.TextBox examResult5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox examResult6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox code7;
        private System.Windows.Forms.TextBox examResult7;
        private System.Windows.Forms.TextBox code8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox code9;
        private System.Windows.Forms.TextBox examResult8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox examResult9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label outputResult;
        private System.Windows.Forms.Button calculate;
        private System.Windows.Forms.Button clear;
    }
}

