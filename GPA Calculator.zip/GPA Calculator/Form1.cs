﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GPA_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculate_Click(object sender, EventArgs e)
        {
            decimal codes1 = decimal.Parse(code1.Text.Trim());
            decimal codes2 = decimal.Parse(code2.Text.Trim());
            decimal codes3 = decimal.Parse(code3.Text.Trim());
            decimal codes4 = decimal.Parse(code4.Text.Trim());
            decimal codes5 = decimal.Parse(code5.Text.Trim());
            decimal codes6 = decimal.Parse(code6.Text.Trim());
            decimal codes7 = decimal.Parse(code7.Text.Trim());
            decimal codes8 = decimal.Parse(code8.Text.Trim());
            decimal codes9 = decimal.Parse(code9.Text.Trim());

            

              
            String result1 = examResult1.Text.Trim();
            String result2 = examResult2.Text.Trim();
            String result3 = examResult3.Text.Trim();
            String result4 = examResult4.Text.Trim();
            String result5 = examResult5.Text.Trim();
            String result6 = examResult6.Text.Trim();
            String result7 = examResult7.Text.Trim();
            String result8 = examResult8.Text.Trim();
            String result9 = examResult9.Text.Trim();

            double oneResult = 0;
            double twoResult = 0;
            double threeResult = 0;
            double fourResult = 0;
            double fiveResult = 0;
            double sixResult = 0;
            double sevenResult = 0;
            double eightResult = 0;
            double nightResult = 0;
            double sumResult = 0;
            decimal totalResult = 0;


            switch (result1.ToLower())
            {
                case "a+":
                    oneResult = (Double)codes1 * 4;
                    break;
                case "a":
                    oneResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    oneResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    oneResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    oneResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    oneResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    oneResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    oneResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    oneResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    oneResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    oneResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();

            switch (result2.ToLower())
            {
                case "a+":
                    twoResult = (Double)codes1 * 4;
                    break;
                case "a":
                    twoResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    twoResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    twoResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    twoResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    twoResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    twoResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    twoResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    twoResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    twoResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    twoResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();
            
            switch (result3.ToLower())
            {
                case "a+":
                    threeResult = (Double)codes1 * 4;
                    break;
                case "a":
                    threeResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    threeResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    threeResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    threeResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    threeResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    threeResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    threeResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    threeResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    threeResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    threeResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();
            switch (result4.ToLower())
            {
                case "a+":
                    fourResult = (Double)codes1 * 4;
                    break;
                case "a":
                    fourResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    fourResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    fourResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    fourResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    fourResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    fourResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    fourResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    fourResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    fourResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    fourResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();
            switch (result5.ToLower())
            {
                case "a+":
                    fiveResult = (Double)codes1 * 4;
                    break;
                case "a":
                    fiveResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    fiveResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    fiveResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    fiveResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    fiveResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    fiveResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    fiveResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    fiveResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    fiveResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    fiveResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();
            switch (result6.ToLower())
            {
                case "a+":
                    sixResult = (Double)codes1 * 4;
                    break;
                case "a":
                    sixResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    sixResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    sixResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    sixResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    sixResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    sixResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    sixResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    sixResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    sixResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    sixResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();
            switch (result7.ToLower())
            {
                case "a+":
                    sevenResult = (Double)codes1 * 4;
                    break;
                case "a":
                    sevenResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    sevenResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    sevenResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    sevenResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    sevenResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    sevenResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    sevenResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    sevenResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    sevenResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    sevenResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();
            switch (result8.ToLower())
            {
                case "a+":
                    eightResult = (Double)codes1 * 4;
                    break;
                case "a":
                    eightResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    eightResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    eightResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    eightResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    eightResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    eightResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    eightResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    eightResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    eightResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    eightResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            //outputResult.Text = oneResult.ToString();
            switch (result9.ToLower())
            {
                case "a+":
                    nightResult = (Double)codes1 * 4;
                    break;
                case "a":
                    nightResult = (Double)codes1 * 4;
                    break;
                case "a-":
                    nightResult = (Double)codes1 * 3.7;
                    break;
                case "b+":
                    nightResult = (Double)codes1 * 3.3;
                    break;
                case "b":
                    nightResult = (Double)codes1 * 3;
                    break;
                case "b-":
                    nightResult = (Double)codes1 * 2.7;
                    break;
                case "c+":
                    nightResult = (Double)codes1 * 2.3;
                    break;
                case "c":
                    nightResult = (Double)codes1 * 2;
                    break;
                case "c-":
                    nightResult = (Double)codes1 * 1.7;
                    break;
                case "d+":
                    nightResult = (Double)codes1 * 1.3;
                    break;
                case "d":
                    nightResult = (Double)codes1 * 1;
                    break;
                default:
                    outputResult.Text = "Invalid input. Please enter A, B, C, D";
                    break;
            }
            sumResult = oneResult + twoResult + threeResult + fourResult + fiveResult + sixResult + sevenResult + eightResult + nightResult;
            totalResult = codes1 + codes2 + codes3 + codes4 + codes5 + codes6 + codes7 + codes8 + codes9;
            double results = (sumResult / (double)totalResult);
            outputResult.Text = results.ToString();


        }

        private void clear_Click(object sender, EventArgs e)
        {
            code1.Text = "";
            code2.Text = "";
            code3.Text = "";
            code4.Text = "";
            code5.Text = "";
            code6.Text = "";
            code7.Text = "";
            code8.Text = "";
            code9.Text = "";

            examResult1.Text = "";
            examResult2.Text = "";
            examResult3.Text = "";
            examResult4.Text = "";
            examResult5.Text = "";
            examResult6.Text = "";
            examResult7.Text = "";
            examResult8.Text = "";
            examResult9.Text = "";
            outputResult.Text = "Result";
        }
    }
}
